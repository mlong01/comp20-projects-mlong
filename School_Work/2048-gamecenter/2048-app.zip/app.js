var express = require("express");
var http = require('http');
var path = require('path');

var mongo = require ('mongodb');


var app = express();


var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/local';


// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(express.json());
app.use(express.urlencoded());


app.get('/', function (req, res){

  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, col){
        col.find().sort({score:-1}).limit(100).toArray(function(err, cursor) {
            var indexPage = "<!DOCTYPE HTML><html><head><title>2048 Game Center</title></head></body><h1>2048 Game Center</h1><table><tr><th>User</th><th>Score</th><th>Timestamp</th></tr>";
            for (var count = 0; count < cursor.length; count++) {
                indexPage += "<tr><td>" + cursor[count].playerName + "</td><td>" + cursor[count].score + "</td><td>" + cursor[count].timestamp + "</td></tr>";
            }
            indexPage += "</table></body></html>"
            res.send(indexPage);
        });

    });
  });
});


app.get('/scores.json', function (req, res){
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
  
    mongo.Db.connect(mongoUri, function (err, db){
        db.collection("scores", function (er, col){
            if (req.query.username==undefined){
                res.send([]);
            } else {
                col.find({username:req.query.username}).toArray(function(e, x){
                    res.send(x);
                });
            }
        });
    });
});


app.post('/submit.json', function (req, res){
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
  
    mongo.Db.connect(mongoUri, function (err, db){
        db.collection("scores", function (er, collection){
            var username = req.body.username;
            var score = parseInt(req.body.score);
            var grid = req.body.grid;
            var timestamp = new Date().toGMTString();
            collection.insert({"score": score, "playerName": username, "timestamp":timestamp, "grid":grid}, function (err, r){});
            res.send("Score sent!");
        });
    });
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});